import { GoogleGenAI, Type } from "@google/genai";
import type { PawnPower } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. Using mocked data.");
}

const ai = process.env.API_KEY ? new GoogleGenAI({ apiKey: process.env.API_KEY }) : null;

const MOCKED_PAWNS: PawnPower[] = [
    { id: 'mock1', name: "Golden Pawn", description: "Earns +$2 bonus gold on capture.", cost: 20 },
    { id: 'mock2', name: "Sturdy Pawn", description: "Can survive one hit and becomes a normal pawn.", cost: 25 },
    { id: 'mock3', name: "Advancing Pawn", description: "Can move two squares forward from any position.", cost: 15 },
];

export async function generatePawnAbilities(count: number): Promise<PawnPower[]> {
  if (!ai) {
    console.log("Using mocked pawn abilities.");
    return MOCKED_PAWNS.slice(0, count).map(p => ({...p, id: `mock-${Date.now()}-${Math.random()}`}));
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate ${count} unique abilities for a chess pawn in a roguelike game. Each ability should have a name, a concise description of its effect, and a suggested cost in gold (from 5 to 50). The abilities should be creative and affect movement, capture, economy, or defense. Do not repeat abilities.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: {
                type: Type.STRING,
                description: 'The creative name of the pawn ability.',
              },
              description: {
                type: Type.STRING,
                description: 'A brief explanation of what the ability does.',
              },
              cost: {
                type: Type.INTEGER,
                description: 'The cost of the pawn in gold, between 5 and 50.',
              },
            },
            required: ["name", "description", "cost"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const abilities = JSON.parse(jsonText);
    
    return abilities.map((ability: Omit<PawnPower, 'id'>) => ({
        ...ability,
        id: `${ability.name.replace(/\s/g, '')}-${Date.now()}`
    }));

  } catch (error) {
    console.error("Error generating pawn abilities with Gemini, returning mocked data:", error);
    return MOCKED_PAWNS.slice(0, count).map(p => ({...p, id: `mock-err-${Date.now()}-${Math.random()}`}));
  }
}