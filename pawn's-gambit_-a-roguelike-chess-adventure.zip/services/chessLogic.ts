import { Board, Piece, PieceType, PlayerColor, Position, Square, BoardRules } from '../types';

export const PIECE_VALUES: { [key in PieceType]: number } = {
    [PieceType.PAWN]: 1,
    [PieceType.KNIGHT]: 3,
    [PieceType.BISHOP]: 3,
    [PieceType.ROOK]: 5,
    [PieceType.QUEEN]: 9,
    [PieceType.KING]: 100,
};

export function createInitialBoard(): Board {
    const board: Board = Array(8).fill(null).map(() => Array(8).fill(null));
    
    const placePiece = (row: number, col: number, type: PieceType, color: PlayerColor, isVisible = true) => {
        board[row][col] = { id: `${type}-${color}-${row}-${col}`, type, color, isVisible };
    };

    // Place Black Pieces
    placePiece(0, 0, PieceType.ROOK, PlayerColor.BLACK);
    placePiece(0, 1, PieceType.KNIGHT, PlayerColor.BLACK);
    placePiece(0, 2, PieceType.BISHOP, PlayerColor.BLACK);
    placePiece(0, 3, PieceType.QUEEN, PlayerColor.BLACK);
    placePiece(0, 4, PieceType.KING, PlayerColor.BLACK, false); // King is initially invisible
    placePiece(0, 5, PieceType.BISHOP, PlayerColor.BLACK);
    placePiece(0, 6, PieceType.KNIGHT, PlayerColor.BLACK);
    placePiece(0, 7, PieceType.ROOK, PlayerColor.BLACK);
    for (let i = 0; i < 8; i++) {
        placePiece(1, i, PieceType.PAWN, PlayerColor.BLACK);
    }

    // Place White Pieces
    placePiece(7, 0, PieceType.ROOK, PlayerColor.WHITE);
    placePiece(7, 1, PieceType.KNIGHT, PlayerColor.WHITE);
    placePiece(7, 2, PieceType.BISHOP, PlayerColor.WHITE);
    placePiece(7, 3, PieceType.QUEEN, PlayerColor.WHITE);
    placePiece(7, 4, PieceType.KING, PlayerColor.WHITE);
    placePiece(7, 5, PieceType.BISHOP, PlayerColor.WHITE);
    placePiece(7, 6, PieceType.KNIGHT, PlayerColor.WHITE);
    placePiece(7, 7, PieceType.ROOK, PlayerColor.WHITE);
    for (let i = 0; i < 8; i++) {
        placePiece(6, i, PieceType.PAWN, PlayerColor.WHITE);
    }
    
    return board;
}

function isWithinBounds({ row, col }: Position): boolean {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
}

export function getValidMoves(board: Board, { row, col }: Position, rules: BoardRules = {}): Position[] {
    const piece = board[row][col];
    if (!piece || piece.isVisible === false) return [];

    const moves: Position[] = [];
    const color = piece.color;
    const opponentColor = color === PlayerColor.WHITE ? PlayerColor.BLACK : PlayerColor.WHITE;

    const addMove = (r: number, c: number) => {
        if (isWithinBounds({ row: r, col: c })) {
            const targetSquare = board[r][c];
            if (targetSquare === null) {
                moves.push({ row: r, col: c });
                return 'empty';
            } else if (targetSquare.isVisible === false) { // Cannot interact with invisible pieces
                return 'blocked';
            } else if (targetSquare.color === opponentColor) {
                moves.push({ row: r, col: c });
                return 'capture';
            }
        }
        return 'blocked';
    };
    
    const addSlidingMoves = (directions: number[][]) => {
        for (const [dr, dc] of directions) {
            let r = row + dr;
            let c = col + dc;
            while(true) {
                const result = addMove(r, c);
                if (result === 'blocked' || result === 'capture') break;
                r += dr;
                c += dc;
            }
        }
    }

    switch (piece.type) {
        case PieceType.PAWN:
            const dir = color === PlayerColor.WHITE ? -1 : 1;
            const startRow = color === PlayerColor.WHITE ? 6 : 1;

            // Forward 1
            if (isWithinBounds({row: row + dir, col}) && board[row + dir][col] === null) {
                addMove(row + dir, col);
            }
            // Forward 2
            if (!rules.pawnHasLimitedFirstMove && row === startRow && board[row + dir][col] === null && board[row + 2 * dir][col] === null) {
                addMove(row + 2 * dir, col);
            }
            // Capture
            [-1, 1].forEach(side => {
                if (isWithinBounds({row: row + dir, col: col + side})) {
                    const captureSquare = board[row + dir][col + side];
                    if (captureSquare && captureSquare.color === opponentColor && captureSquare.isVisible !== false) {
                        addMove(row + dir, col + side);
                    }
                }
            });
            break;
        case PieceType.KNIGHT:
            const knightMoves = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
            knightMoves.forEach(([dr, dc]) => addMove(row + dr, col + dc));
            break;
        case PieceType.ROOK:
            addSlidingMoves([[-1, 0], [1, 0], [0, -1], [0, 1]]);
            break;
        case PieceType.BISHOP:
            addSlidingMoves([[-1, -1], [-1, 1], [1, -1], [1, 1]]);
            break;
        case PieceType.QUEEN:
            addSlidingMoves([[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]]);
            break;
        case PieceType.KING:
            const kingMoves = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]];
            kingMoves.forEach(([dr, dc]) => addMove(row + dr, col + dc));
            break;
    }

    return moves;
}

export function findKing(board: Board, color: PlayerColor): Position | null {
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = board[r][c];
            if (piece && piece.type === PieceType.KING && piece.color === color) {
                return { row: r, col: c };
            }
        }
    }
    return null;
}

export function isCheck(board: Board, kingColor: PlayerColor, rules: BoardRules = {}): boolean {
    const kingPos = findKing(board, kingColor);
    if (!kingPos || board[kingPos.row][kingPos.col]?.isVisible === false) return false;

    const opponentColor = kingColor === PlayerColor.WHITE ? PlayerColor.BLACK : PlayerColor.WHITE;
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = board[r][c];
            if (piece && piece.color === opponentColor && piece.isVisible !== false) {
                const validMoves = getValidMoves(board, { row: r, col: c }, rules);
                if (validMoves.some(move => move.row === kingPos.row && move.col === kingPos.col)) {
                    return true;
                }
            }
        }
    }
    return false;
}

// --- NEW AI LOGIC ---

function evaluateBoard(board: Board): number {
    let totalScore = 0;
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = board[r][c];
            if (piece && piece.isVisible) {
                let score = PIECE_VALUES[piece.type];
                // Add positional bonus for center control
                if ((r === 3 || r === 4) && (c === 3 || c === 4)) {
                    score += 0.2;
                }
                totalScore += (piece.color === PlayerColor.BLACK ? score : -score);
            }
        }
    }
    return totalScore;
}

function minimax(board: Board, depth: number, alpha: number, beta: number, isMaximizingPlayer: boolean, rules: BoardRules): number {
    if (!findKing(board, PlayerColor.WHITE)) return 1000 + depth; // AI wins
    if (!findKing(board, PlayerColor.BLACK)) return -1000 - depth; // Player wins

    if (depth === 0) {
        return evaluateBoard(board);
    }

    const color = isMaximizingPlayer ? PlayerColor.BLACK : PlayerColor.WHITE;
    const allMoves: { from: Position; to: Position }[] = [];
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = board[r][c];
            if (piece && piece.color === color && piece.isVisible) {
                getValidMoves(board, { row: r, col: c }, rules).forEach(move => {
                    allMoves.push({ from: { row: r, col: c }, to: move });
                });
            }
        }
    }

    if (allMoves.length === 0) return evaluateBoard(board);

    if (isMaximizingPlayer) {
        let maxEval = -Infinity;
        for (const move of allMoves) {
            const newBoard = JSON.parse(JSON.stringify(board));
            newBoard[move.to.row][move.to.col] = newBoard[move.from.row][move.from.col];
            newBoard[move.from.row][move.from.col] = null;
            const evaluation = minimax(newBoard, depth - 1, alpha, beta, false, rules);
            maxEval = Math.max(maxEval, evaluation);
            alpha = Math.max(alpha, evaluation);
            if (beta <= alpha) break;
        }
        return maxEval;
    } else {
        let minEval = Infinity;
        for (const move of allMoves) {
            const newBoard = JSON.parse(JSON.stringify(board));
            newBoard[move.to.row][move.to.col] = newBoard[move.from.row][move.from.col];
            newBoard[move.from.row][move.from.col] = null;
            const evaluation = minimax(newBoard, depth - 1, alpha, beta, true, rules);
            minEval = Math.min(minEval, evaluation);
            beta = Math.min(beta, evaluation);
            if (beta <= alpha) break;
        }
        return minEval;
    }
}

export function findBestMove(board: Board, rules: BoardRules, level: number): { from: Position; to: Position } | null {
    let bestMove: { from: Position; to: Position } | null = null;
    let bestValue = -Infinity;

    const allMoves: { from: Position; to: Position }[] = [];
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = board[r][c];
            if (piece && piece.color === PlayerColor.BLACK && piece.isVisible) {
                getValidMoves(board, { row: r, col: c }, rules).forEach(move => {
                    allMoves.push({ from: { row: r, col: c }, to: move });
                });
            }
        }
    }

    if (allMoves.length === 0) return null;

    // Randomize to prevent deterministic play
    allMoves.sort(() => Math.random() - 0.5);

    // --- DIFFICULTY SCALING ---
    // Level 1: Depth 0 (Greedy)
    // Levels 2-4: Depth 1
    // Levels 5+: Depth 2
    const depth = level === 1 ? 0 : (level < 5 ? 1 : 2);

    for (const move of allMoves) {
        const newBoard = JSON.parse(JSON.stringify(board));
        newBoard[move.to.row][move.to.col] = newBoard[move.from.row][move.from.col];
        newBoard[move.from.row][move.from.col] = null;
        
        const moveValue = minimax(newBoard, depth, -Infinity, Infinity, false, rules);

        if (moveValue > bestValue) {
            bestValue = moveValue;
            bestMove = move;
        }
    }
    return bestMove;
}