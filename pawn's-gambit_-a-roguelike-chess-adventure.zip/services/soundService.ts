// Simple audio service to avoid creating new Audio objects on every play.
// Sounds are short, royalty-free WAVs encoded in base64.

// A simple, short click for movement
const moveSound = new Audio("data:audio/wav;base64,UklGRkIAAABXQVZFZm10IBAAAAABAAEAESsAABKxAAACABAAZGF0YQQAAAAAAAC/gUSC");

// A slightly more impactful sound for capture
const captureSound = new Audio("data:audio/wav;base64,UklGRkYAAABXQVZFZm10IBAAAAABAAEAESsAABKxAAACABAAZGF0YQIAAAAAAP//BA==");

// A more dramatic sound for the king's arrival
const summonSound = new Audio("data:audio/wav;base64,UklGRlIAAABXQVZFZm10IBAAAAABAAEAESsAABKxAAACABAAZGF0YUgAAAAA//8DAGUAbgB1AHsAgwCTALUAvgDAAMoA1QDeAPIA/wD5AP8A+QDvAOcA3gDXANAAygDJAIwAhABzAGkAXQBW");

function playSound(audio: HTMLAudioElement) {
    // This allows re-playing the sound before it has finished.
    audio.currentTime = 0;
    audio.play().catch(e => console.error("Audio playback failed.", e));
}

export function playMove() {
    playSound(moveSound);
}

export function playCapture() {
    playSound(captureSound);
}

export function playSummon() {
    playSound(summonSound);
}
